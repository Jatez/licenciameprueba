import axios, { AxiosInstance, AxiosRequestConfig } from "axios";
import { useAuthStore } from "@/stores/authStore";

/**
 * Real HTTP client for the future backend.
 * Currently unused — endpoints still resolve through src/api/mocks/.
 * When backend lands, swap mock calls for `http.get/post/...` inside
 * each file in src/api/endpoints/. This module's API is stable.
 */
export const http: AxiosInstance = axios.create({
  baseURL: "/api/v2",
  timeout: 15000,
  headers: { "Content-Type": "application/json" },
});

/**
 * Request interceptor — injects the Bearer token from the auth store.
 * Reading from the store on every request keeps the token always fresh
 * (no stale closures after login/refresh).
 */
http.interceptors.request.use((config) => {
  const token = useAuthStore.getState().accessToken;
  if (token && config.headers) {
    (config.headers as unknown as Record<string, string>).Authorization = `Bearer ${token}`;
  }
  return config;
});

/**
 * Response interceptor — on 401 attempts a single silent refresh, retries
 * the original request, and on failure clears the session. Implemented now
 * even though endpoints currently resolve through mocks.
 */
let refreshing: Promise<string | null> | null = null;

async function attemptRefresh(): Promise<string | null> {
  const refreshToken = useAuthStore.getState().refreshToken;
  if (!refreshToken) return null;
  try {
    const { refresh } = await import("@/modules/auth/api");
    const tokens = await refresh({ refreshToken });
    useAuthStore.getState().setTokens(tokens);
    return tokens.accessToken;
  } catch {
    return null;
  }
}

http.interceptors.response.use(
  (res) => res,
  async (err) => {
    const originalRequest = err?.config as
      | (AxiosRequestConfig & { _retry?: boolean })
      | undefined;

    if (err?.response?.status === 401 && originalRequest && !originalRequest._retry) {
      originalRequest._retry = true;
      refreshing = refreshing ?? attemptRefresh();
      const newToken = await refreshing;
      refreshing = null;
      if (newToken) {
        if (originalRequest.headers) {
          (originalRequest.headers as unknown as Record<string, string>).Authorization = `Bearer ${newToken}`;
        }
        return http.request(originalRequest);
      }
      useAuthStore.getState().logout();
    }

    // Backend will return ApiError shape { code, message, field? } in body.
    const data = err?.response?.data;
    if (data && typeof data === "object" && "code" in data && "message" in data) {
      return Promise.reject(data);
    }
    return Promise.reject({
      code: "network_error",
      message: err?.message ?? "Network error",
    });
  },
);
