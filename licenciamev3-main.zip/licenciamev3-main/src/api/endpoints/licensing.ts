/**
 * Licensing mock endpoints (F-05).
 *
 * Same signatures backend will implement. Components only depend on this file,
 * never on `mocks/licensing.mocks.ts` directly.
 */
import type {
  CancelLicenseRequest,
  CancelLicenseResponse,
  IssueLicenseRequest,
  IssueLicenseResponse,
  License,
  LicenseListAggregates,
  LicenseStatusFull,
  LicensingTermsResponse,
  LicensingValidationRequest,
  LicensingValidationResponse,
  ListLicensesRequest,
  ListLicensesResponse,
  UsageTypeCatalog,
} from "@/api/types";
import { mockDelay, mockError } from "@/api/client";
import {
  MOCK_LICENSING_TERMS,
  MOCK_WALLET_INSUFFICIENT_BALANCE,
  USAGE_TYPE_CATALOG,
  addIssuedLicense,
  ensureSeedLicenses,
  findIssuedLicense,
  generateLicenseTokenId,
  getIssuedLicenses,
  readMockScenario,
  updateIssuedLicense,
} from "@/api/mocks/licensing.mocks";
import {
  consumeFromBags,
  getActiveBags,
  getCurrentWalletBalance,
  refundToBag,
} from "@/api/mocks/packages.mocks";
import { catalogApi } from "./catalog";

function delay(min: number, max: number): Promise<void> {
  return new Promise((resolve) => {
    const ms = min + Math.random() * (max - min);
    setTimeout(resolve, ms);
  });
}

function getEffectiveBalance(): number {
  return readMockScenario() === "insufficient"
    ? MOCK_WALLET_INSUFFICIENT_BALANCE
    : getCurrentWalletBalance();
}

export const licensingApi = {
  async getUsageTypeCatalog(): Promise<UsageTypeCatalog> {
    await delay(200, 400);
    return USAGE_TYPE_CATALOG;
  },

  async getLicensingTerms(): Promise<LicensingTermsResponse> {
    await delay(200, 400);
    return MOCK_LICENSING_TERMS;
  },

  async validateLicensing(
    req: LicensingValidationRequest,
  ): Promise<LicensingValidationResponse> {
    await delay(300, 600);
    const scenario = readMockScenario();
    const definition = USAGE_TYPE_CATALOG.find((u) => u.id === req.usageType);
    const requiredCredits = definition?.creditCost ?? 0;
    const currentBalance = getEffectiveBalance();
    const reasons: LicensingValidationResponse["reasons"] = [];

    // Resolve track existence + licensability via catalog mock.
    try {
      const detail = await catalogApi.getTrackById(req.trackId);
      const supportsUsage = detail.track.platformLicensability.some((p) =>
        p.allowedUsageTypes.includes(req.usageType),
      );
      if (!supportsUsage) reasons.push("TRACK_NOT_LICENSABLE_FOR_USAGE");
    } catch (e) {
      const code = (e as { code?: string }).code;
      if (code === "TRACK_REMOVED") reasons.push("TRACK_REMOVED");
      else reasons.push("TRACK_NOT_FOUND");
    }

    if (scenario === "not-licensable" && req.usageType === "paid-post") {
      if (!reasons.includes("TRACK_NOT_LICENSABLE_FOR_USAGE")) {
        reasons.push("TRACK_NOT_LICENSABLE_FOR_USAGE");
      }
    }

    if (currentBalance < requiredCredits) reasons.push("INSUFFICIENT_CREDITS");

    return {
      allowed: reasons.length === 0,
      reasons,
      requiredCredits,
      currentBalance,
      resultingBalance: Math.max(0, currentBalance - requiredCredits),
    };
  },

  async issueLicense(req: IssueLicenseRequest): Promise<IssueLicenseResponse> {
    await mockDelay();
    await delay(600, 1100); // total 800-1500 perceived
    const scenario = readMockScenario();

    if (scenario === "wallet-expired") {
      mockError(
        "WALLET_EXPIRED_DURING_TRANSACTION",
        "Tu bolsa de créditos expiró. Renueva para continuar.",
      );
    }
    if (scenario === "concurrent") {
      mockError(
        "CONCURRENT_LICENSING_DETECTED",
        "Otra licencia se está procesando con esta misma canción. Inténtalo nuevamente.",
      );
    }
    if (req.acceptedTermsVersion !== MOCK_LICENSING_TERMS.version) {
      mockError(
        "TERMS_VERSION_OUTDATED",
        "Los términos legales se actualizaron. Vuelve a revisarlos.",
      );
    }

    const definition = USAGE_TYPE_CATALOG.find((u) => u.id === req.usageType);
    const cost = definition?.creditCost ?? 0;
    const balance = getEffectiveBalance();
    if (balance < cost) {
      mockError("INSUFFICIENT_CREDITS", "Saldo insuficiente para esta licencia.");
    }

    const detail = await catalogApi.getTrackById(req.trackId);
    const issuedAt = new Date().toISOString();
    const cancellableUntil = new Date(
      Date.now() + MOCK_LICENSING_TERMS.cancellationPolicy.cancellableWindowHours * 3600_000,
    ).toISOString();

    const license: License = {
      id: crypto.randomUUID(),
      licenseTokenId: generateLicenseTokenId(),
      companyId: "company-mock-001",
      companyName: "Marca Demo S.A.S.",
      trackId: detail.track.id,
      trackSnapshot: {
        title: detail.track.title,
        artist: detail.track.artist,
        album: detail.track.album,
        durationSec: detail.track.durationSec,
        coverUrl: detail.track.coverUrl,
        isrc: detail.track.isrc,
      },
      usageType: req.usageType,
      creditsConsumed: cost,
      status: "active",
      issuedAt,
      expiresAt: req.usageType === "monthly-extended"
        ? new Date(Date.now() + 30 * 86400_000).toISOString()
        : null,
      consumedAt: null,
      cancelledAt: null,
      cancellationReason: null,
      cancellableUntil,
      issuedByUserId: "user-mock-001",
      issuedByUserName: "Usuario Demo",
    };

    addIssuedLicense(license);

    // Decrement wallet via FIFO unless we're in the synthetic insufficient scenario.
    if (readMockScenario() !== "insufficient") {
      consumeFromBags(cost);
    }

    return {
      license,
      newWalletBalance: getEffectiveBalance(),
      certificateAvailable: true,
    };
  },

  async getLicenseById(licenseId: string): Promise<License> {
    ensureSeedLicenses();
    await delay(200, 500);
    const found = findIssuedLicense(licenseId);
    if (!found) mockError("LICENSE_NOT_FOUND", "Licencia no encontrada.");
    return found!;
  },

  async listLicenses(req: ListLicensesRequest): Promise<ListLicensesResponse> {
    ensureSeedLicenses();
    await delay(400, 700);

    const all = getIssuedLicenses();
    const aggregates = computeAggregates(all);
    const filtered = applyFilters(all, req);
    const sorted = applySort(filtered, req.filters.sort);

    const totalLicenses = sorted.length;
    const totalPages = Math.max(1, Math.ceil(totalLicenses / req.pageSize));
    const safePage = Math.min(Math.max(1, req.page), totalPages);
    const start = (safePage - 1) * req.pageSize;
    const licenses = sorted.slice(start, start + req.pageSize);

    return {
      licenses,
      page: safePage,
      pageSize: req.pageSize,
      totalLicenses,
      totalPages,
      aggregates,
    };
  },

  async cancelLicense(req: CancelLicenseRequest): Promise<CancelLicenseResponse> {
    ensureSeedLicenses();
    await delay(400, 700);

    const found = findIssuedLicense(req.licenseId);
    if (!found) mockError("LICENSE_NOT_FOUND", "Licencia no encontrada.");
    if (found!.status === "cancelled") {
      mockError("LICENSE_ALREADY_CANCELLED", "Esta licencia ya estaba anulada.");
    }
    if (found!.status === "consumed") {
      mockError(
        "LICENSE_ALREADY_CONSUMED",
        "Esta licencia ya fue consumida y no puede anularse.",
      );
    }
    if (found!.cancellableUntil && new Date(found!.cancellableUntil).getTime() < Date.now()) {
      mockError(
        "CANCELLATION_WINDOW_EXPIRED",
        "La ventana de anulación ya expiró.",
      );
    }

    const reasonText = req.reason.trim().length > 0
      ? `${req.reasonCategory}: ${req.reason.trim()}`
      : req.reasonCategory;

    const updated = updateIssuedLicense(req.licenseId, {
      status: "cancelled" as LicenseStatusFull,
      cancelledAt: new Date().toISOString(),
      cancellationReason: reasonText,
    })!;

    const refunded = updated.creditsConsumed;
    // Refund to the earliest active bag (best-effort; a real backend would
    // know the originating bag from the issuance ledger).
    const target = getActiveBags()[0];
    refundToBag(target?.id ?? null, refunded);
    const newBalance = getEffectiveBalance();

    return {
      license: updated,
      refundedCredits: refunded,
      newWalletBalance: newBalance,
    };
  },
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

function computeAggregates(all: License[]): LicenseListAggregates {
  const agg: LicenseListAggregates = {
    totalActive: 0,
    totalConsumed: 0,
    totalExpired: 0,
    totalCancelled: 0,
    totalCreditsConsumed: 0,
  };
  for (const l of all) {
    if (l.status === "active") agg.totalActive += 1;
    else if (l.status === "consumed") agg.totalConsumed += 1;
    else if (l.status === "expired") agg.totalExpired += 1;
    else if (l.status === "cancelled") agg.totalCancelled += 1;
    if (l.status !== "cancelled") agg.totalCreditsConsumed += l.creditsConsumed;
  }
  return agg;
}

function applyFilters(all: License[], req: ListLicensesRequest): License[] {
  const { search, statuses, usageTypes, dateRange } = req.filters;
  const q = search.trim().toLowerCase();
  const fromMs = dateRange.from ? new Date(dateRange.from).getTime() : null;
  const toMs = dateRange.to ? new Date(dateRange.to).getTime() : null;
  return all.filter((l) => {
    if (statuses.length && !statuses.includes(l.status)) return false;
    if (usageTypes.length && !usageTypes.includes(l.usageType)) return false;
    if (fromMs != null && new Date(l.issuedAt).getTime() < fromMs) return false;
    if (toMs != null && new Date(l.issuedAt).getTime() > toMs) return false;
    if (q) {
      const haystack = `${l.licenseTokenId} ${l.trackSnapshot.title} ${l.trackSnapshot.artist}`.toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });
}

function applySort(licenses: License[], sort: ListLicensesRequest["filters"]["sort"]): License[] {
  const copy = licenses.slice();
  switch (sort) {
    case "issuedAt-asc":
      return copy.sort((a, b) => +new Date(a.issuedAt) - +new Date(b.issuedAt));
    case "track-asc":
      return copy.sort((a, b) => a.trackSnapshot.title.localeCompare(b.trackSnapshot.title));
    case "creditsConsumed-desc":
      return copy.sort((a, b) => b.creditsConsumed - a.creditsConsumed);
    case "creditsConsumed-asc":
      return copy.sort((a, b) => a.creditsConsumed - b.creditsConsumed);
    case "issuedAt-desc":
    default:
      return copy.sort((a, b) => +new Date(b.issuedAt) - +new Date(a.issuedAt));
  }
}
