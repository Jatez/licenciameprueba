import { mockDelay, mockError } from "../client";
import {
  MOCK_TRIGGERS,
  mockCompanyDualtee,
  mockOnboardingSteps,
  mockTokensPair,
  mockUserAdmin,
  mockUserOnboardingDone,
  mockUserVerified,
} from "../mocks/auth.mocks";
import type {
  CompleteOnboardingRequest,
  CompleteOnboardingResponse,
  RegisterRequest,
  RegisterResponse,
  ResendVerificationRequest,
  ResendVerificationResponse,
  SkipOnboardingResponse,
  User,
  VerifyEmailRequest,
  VerifyEmailResponse,
} from "../types";

/**
 * Module-scoped mock session — simulates server-side persistence so that
 * subsequent getCurrentUser() calls reflect the result of register/verify/
 * complete/skip mutations. Backend real reemplaza esto con persistencia en BD.
 */
const mockSession: { user: User } = { user: mockUserVerified };

/**
 * Mock auth endpoints. Same signatures the real backend will expose.
 *
 * Errors are forced via "special tokens" (see MOCK_TRIGGERS):
 *   - register: email/password/country/terms specific values trigger errors.
 *   - verifyEmail: token strings like MOCK_EXPIRED_TOKEN trigger errors.
 *   - resendVerification: a cooldown email triggers RESEND_COOLDOWN_ACTIVE.
 *
 * This pattern is composable, env-flag-free, and disappears the day the
 * real API arrives — endpoints stay identical, mocks/ folder is deleted.
 */

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function register(payload: RegisterRequest): Promise<RegisterResponse> {
  await mockDelay();

  if (!payload.acceptedTerms) {
    mockError("TERMS_NOT_ACCEPTED", "Debes aceptar los términos.", "acceptedTerms");
  }
  if (!EMAIL_REGEX.test(payload.email)) {
    mockError("INVALID_EMAIL", "Email inválido.", "email");
  }
  if (payload.password.length < 8) {
    mockError("PASSWORD_TOO_SHORT", "La contraseña debe tener al menos 8 caracteres.", "password");
  }
  if (payload.countryCode === MOCK_TRIGGERS.invalidCountry || payload.countryCode.length !== 2) {
    mockError("INVALID_COUNTRY_CODE", "Código de país inválido.", "countryCode");
  }
  if (payload.email.toLowerCase() === MOCK_TRIGGERS.emailAlreadyTaken) {
    mockError("EMAIL_ALREADY_EXISTS", "Este email ya está registrado.", "email");
  }

  const user: User = {
    ...mockUserAdmin,
    email: payload.email,
    fullName: payload.fullName,
    role: payload.role,
  };
  const company = {
    ...mockCompanyDualtee,
    name: payload.companyName,
    countryCode: payload.countryCode,
  };

  mockSession.user = user;

  return {
    user,
    company,
    tokens: mockTokensPair,
    verificationEmailSent: true,
  };
}

export async function verifyEmail(payload: VerifyEmailRequest): Promise<VerifyEmailResponse> {
  await mockDelay();

  switch (payload.token) {
    case MOCK_TRIGGERS.tokens.expired:
      mockError("VERIFICATION_TOKEN_EXPIRED", "El enlace de verificación expiró.");
      break;
    case MOCK_TRIGGERS.tokens.invalid:
      mockError("VERIFICATION_TOKEN_INVALID", "El enlace de verificación es inválido.");
      break;
    case MOCK_TRIGGERS.tokens.alreadyVerified:
      mockError("EMAIL_ALREADY_VERIFIED", "Este email ya estaba verificado.");
      break;
    default:
      break;
  }

  if (!payload.token || payload.token.length < 8) {
    mockError("VERIFICATION_TOKEN_INVALID", "El enlace de verificación es inválido.");
  }

  mockSession.user = {
    ...mockSession.user,
    emailVerified: true,
  };
  return { user: mockSession.user };
}

export async function resendVerification(
  payload: ResendVerificationRequest,
): Promise<ResendVerificationResponse> {
  await mockDelay();

  if (payload.email.toLowerCase() === MOCK_TRIGGERS.resendCooldown) {
    mockError("RESEND_COOLDOWN_ACTIVE", "Espera unos segundos antes de reenviar.");
  }

  const nextRetry = new Date(Date.now() + 60_000).toISOString();
  return { sent: true, nextRetryAvailableAt: nextRetry };
}

export async function getCurrentUser(): Promise<User> {
  await mockDelay();
  return mockSession.user;
}

export async function completeOnboarding(
  payload: CompleteOnboardingRequest,
): Promise<CompleteOnboardingResponse> {
  await mockDelay();
  const finalStep = Math.max(1, Math.min(4, payload.finalStep));
  mockSession.user = {
    ...mockSession.user,
    ...mockUserOnboardingDone,
    email: mockSession.user.email,
    fullName: mockSession.user.fullName,
    role: mockSession.user.role,
    onboardingCompleted: true,
    onboardingSkipped: false,
    onboardingCurrentStep: finalStep,
  };
  return { user: mockSession.user };
}

export async function skipOnboarding(): Promise<SkipOnboardingResponse> {
  await mockDelay();
  mockSession.user = {
    ...mockSession.user,
    ...mockUserOnboardingDone,
    email: mockSession.user.email,
    fullName: mockSession.user.fullName,
    role: mockSession.user.role,
    onboardingCompleted: false,
    onboardingSkipped: true,
  };
  return { user: mockSession.user };
}

/** Static catalog of onboarding steps. Sync, no delay. */
export function listOnboardingSteps() {
  return mockOnboardingSteps;
}
