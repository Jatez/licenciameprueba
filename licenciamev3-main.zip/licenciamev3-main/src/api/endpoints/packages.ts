/**
 * Credit packages mock endpoints (F-04).
 *
 * Same signatures backend will implement. Components only depend on this
 * file, never on `mocks/packages.mocks.ts` directly.
 *
 * Hand-off notes:
 * - `/packages` should come from a server-side configurable catalog.
 * - `createQuote` must lock pricing for ~7 days, ideally tied to session.
 * - `confirmCardPurchase` here is a stub. Real impl wraps Wompi/MercadoPago/PayU.
 *   Backend must NEVER receive raw PAN, only a tokenized reference.
 * - Bank transfer confirmation should be webhook-driven from the bank, not
 *   `devConfirmBankTransfer` (which exists only for the demo).
 * - DIAN electronic invoicing replaces the receipt PDF generated client-side.
 * - FIFO consumption logic is mirrored in `mocks/packages.mocks.ts` and must
 *   be re-implemented server-side in the real debit engine.
 */
import type {
  ConfirmBankTransferIntentRequest,
  ConfirmBankTransferIntentResponse,
  ConfirmCardPurchaseRequest,
  CreatePurchaseQuoteRequest,
  CreditPackage,
  ListPurchasesRequest,
  ListPurchasesResponse,
  Purchase,
  PurchaseQuote,
  WalletAggregate,
} from "@/api/types";
import { mockError } from "@/api/client";
import {
  CREDIT_PACKAGES,
  addBag,
  addPurchase,
  addQuote,
  ensureSeedPackages,
  findPackage,
  findPurchase,
  findQuote,
  generateBagId,
  generatePurchaseId,
  generateQuoteId,
  generateReceiptNumber,
  generateTransferReference,
  getAllPurchases,
  getWalletAggregate,
  makeEvent,
  markPurchaseConfirmed,
  markPurchaseFailed,
  readPurchaseScenario,
  updatePurchase,
} from "@/api/mocks/packages.mocks";

const DAY_MS = 86_400_000;
const MONTH_MS = 30 * DAY_MS;
const HOUR_MS = 3600_000;

function delay(min: number, max: number): Promise<void> {
  return new Promise((r) => setTimeout(r, min + Math.random() * (max - min)));
}

const IVA_RATE = 0.19;

function buildAmounts(priceCop: number) {
  const subtotalCop = Math.round(priceCop / (1 + IVA_RATE));
  const ivaCop = priceCop - subtotalCop;
  return { subtotalCop, ivaCop, totalCop: priceCop };
}

function isCardValid(req: ConfirmCardPurchaseRequest): boolean {
  if (!/^\d{16}$/.test(req.cardNumber.replace(/\s+/g, ""))) return false;
  if (!/^\d{3}$/.test(req.cvv)) return false;
  if (!/^(0[1-9]|1[0-2])$/.test(req.expiryMonth)) return false;
  if (!/^\d{2}$/.test(req.expiryYear)) return false;
  // Expiry must be >= current month/year.
  const now = new Date();
  const yy = Number(req.expiryYear);
  const mm = Number(req.expiryMonth);
  const fullYear = 2000 + yy;
  const expiryDate = new Date(fullYear, mm, 0); // last day of expiry month
  return expiryDate.getTime() >= now.getTime();
}

export const packagesApi = {
  async listPackages(): Promise<CreditPackage[]> {
    await delay(200, 400);
    return CREDIT_PACKAGES.slice();
  },

  async getWallet(): Promise<WalletAggregate> {
    await delay(250, 500);
    return getWalletAggregate();
  },

  async createQuote(req: CreatePurchaseQuoteRequest): Promise<PurchaseQuote> {
    await delay(300, 600);
    const pkg = findPackage(req.packageId);
    if (!pkg) mockError("PACKAGE_NOT_FOUND", "Paquete no encontrado");
    const scenario = readPurchaseScenario();
    const now = Date.now();
    const validUntil = scenario === "quote-expired"
      ? new Date(now - HOUR_MS).toISOString()
      : new Date(now + 7 * DAY_MS).toISOString();
    const amounts = buildAmounts(pkg!.priceCop);
    const quote: PurchaseQuote = {
      id: generateQuoteId(),
      packageId: pkg!.id,
      packageSnapshot: pkg!,
      buyerCompanyName: "Marca Demo S.A.S.",
      buyerCompanyId: "900.123.456-7",
      buyerEmail: "compras@marcademo.co",
      ...amounts,
      createdAt: new Date(now).toISOString(),
      validUntil,
    };
    addQuote(quote);
    return quote;
  },

  async getQuote(quoteId: string): Promise<PurchaseQuote> {
    await delay(200, 400);
    const q = findQuote(quoteId);
    if (!q) mockError("QUOTE_NOT_FOUND", "Cotización no encontrada");
    return q!;
  },

  async confirmCardPurchase(
    req: ConfirmCardPurchaseRequest,
  ): Promise<Purchase> {
    const scenario = readPurchaseScenario();
    const quote = findQuote(req.quoteId);
    if (!quote) mockError("QUOTE_NOT_FOUND", "Cotización no encontrada");
    if (new Date(quote!.validUntil).getTime() < Date.now()) {
      mockError("QUOTE_EXPIRED", "La cotización expiró. Genera una nueva.");
    }
    if (!isCardValid(req)) {
      mockError("CARD_INVALID", "Datos de la tarjeta inválidos");
    }

    const cardLast4 = req.cardNumber.replace(/\s+/g, "").slice(-4);
    const createdAt = new Date().toISOString();
    const purchase: Purchase = {
      id: generatePurchaseId(),
      quoteId: quote!.id,
      packageId: quote!.packageId,
      packageSnapshot: quote!.packageSnapshot,
      paymentMethod: "card-simulated",
      status: "processing",
      subtotalCop: quote!.subtotalCop,
      ivaCop: quote!.ivaCop,
      totalCop: quote!.totalCop,
      createdAt,
      confirmedAt: null,
      failureReason: null,
      receiptNumber: null,
      bagId: null,
      cardLast4,
      transferReference: null,
      events: [
        makeEvent("order_created", createdAt),
        makeEvent("quote_generated", quote!.createdAt),
        makeEvent("payment_initiated", createdAt, null, "user"),
      ],
      creditsCredited: 0,
      manualReviewReason: null,
      isProvisionalDocument: true,
    };
    addPurchase(purchase);

    // Simulated gateway latency.
    const slow = scenario === "processing-slow";
    await delay(slow ? 4000 : 1500, slow ? 4500 : 2500);

    if (scenario === "card-decline" || req.forceFailure) {
      const failed = markPurchaseFailed(purchase.id, "PAYMENT_DECLINED");
      mockError(
        "PAYMENT_DECLINED",
        "Tu banco rechazó la transacción. Intenta con otra tarjeta.",
      );
      return failed!;
    }

    // Success: create bag + confirm.
    const bagId = generateBagId();
    const now = Date.now();
    addBag({
      id: bagId,
      packageId: purchase.packageId,
      packageName: purchase.packageSnapshot.name,
      creditsTotal: purchase.packageSnapshot.credits,
      creditsRemaining: purchase.packageSnapshot.credits,
      purchasedAt: new Date(now).toISOString(),
      expiresAt: new Date(
        now + purchase.packageSnapshot.validityMonths * MONTH_MS,
      ).toISOString(),
      status: "active",
      purchaseId: purchase.id,
    });
    return markPurchaseConfirmed(
      purchase.id,
      bagId,
      generateReceiptNumber(),
    )!;
  },

  async confirmBankTransferIntent(
    req: ConfirmBankTransferIntentRequest,
  ): Promise<ConfirmBankTransferIntentResponse> {
    await delay(600, 900);
    const quote = findQuote(req.quoteId);
    if (!quote) mockError("QUOTE_NOT_FOUND", "Cotización no encontrada");
    if (new Date(quote!.validUntil).getTime() < Date.now()) {
      mockError("QUOTE_EXPIRED", "La cotización expiró. Genera una nueva.");
    }
    const reference = generateTransferReference();
    const createdAt = new Date().toISOString();
    const purchase: Purchase = {
      id: generatePurchaseId(),
      quoteId: quote!.id,
      packageId: quote!.packageId,
      packageSnapshot: quote!.packageSnapshot,
      paymentMethod: "bank-transfer-simulated",
      status: "pending_payment",
      subtotalCop: quote!.subtotalCop,
      ivaCop: quote!.ivaCop,
      totalCop: quote!.totalCop,
      createdAt,
      confirmedAt: null,
      failureReason: null,
      receiptNumber: null,
      bagId: null,
      cardLast4: null,
      transferReference: reference,
      events: [
        makeEvent("order_created", createdAt),
        makeEvent("quote_generated", quote!.createdAt),
        makeEvent("payment_initiated", createdAt, null, "user"),
        makeEvent("payment_pending", createdAt),
      ],
      creditsCredited: 0,
      manualReviewReason: null,
      isProvisionalDocument: true,
    };
    addPurchase(purchase);
    return {
      purchase,
      instructions: {
        bankName: "Banco Demo S.A.",
        accountType: "Cuenta corriente",
        accountNumber: "123-456789-01",
        accountHolder: "Licénciame Colombia S.A.S.",
        nit: "900.123.456-7",
        reference,
        amountCop: purchase.totalCop,
        expiresAt: new Date(Date.now() + 72 * HOUR_MS).toISOString(),
      },
    };
  },

  /** Demo helper: simulates the bank webhook confirming the transfer. */
  async devConfirmBankTransfer(purchaseId: string): Promise<Purchase> {
    await delay(400, 700);
    const purchase = findPurchase(purchaseId);
    if (!purchase) mockError("QUOTE_NOT_FOUND", "Compra no encontrada");
    if (purchase!.status !== "pending" && purchase!.status !== "pending_payment" && purchase!.status !== "pending_confirmation") return purchase!;
    const bagId = generateBagId();
    const now = Date.now();
    addBag({
      id: bagId,
      packageId: purchase!.packageId,
      packageName: purchase!.packageSnapshot.name,
      creditsTotal: purchase!.packageSnapshot.credits,
      creditsRemaining: purchase!.packageSnapshot.credits,
      purchasedAt: new Date(now).toISOString(),
      expiresAt: new Date(
        now + purchase!.packageSnapshot.validityMonths * MONTH_MS,
      ).toISOString(),
      status: "active",
      purchaseId: purchase!.id,
    });
    return markPurchaseConfirmed(
      purchase!.id,
      bagId,
      generateReceiptNumber(),
    )!;
  },

  async listPurchases(
    req: ListPurchasesRequest,
  ): Promise<ListPurchasesResponse> {
    await delay(300, 600);
    ensureSeedPackages();
    const all = getAllPurchases();
    const totalPurchases = all.length;
    const totalPages = Math.max(1, Math.ceil(totalPurchases / req.pageSize));
    const start = (req.page - 1) * req.pageSize;
    return {
      purchases: all.slice(start, start + req.pageSize),
      page: req.page,
      pageSize: req.pageSize,
      totalPurchases,
      totalPages,
    };
  },

  async getPurchaseById(id: string): Promise<Purchase> {
    await delay(200, 400);
    const p = findPurchase(id);
    if (!p) mockError("QUOTE_NOT_FOUND", "Compra no encontrada");
    return p!;
  },
};

// Used by license cancellation flow to refund.
export { refundToBag } from "@/api/mocks/packages.mocks";
// Re-export so other endpoints can read the canonical wallet balance.
export {
  consumeFromBags,
  getCurrentWalletBalance,
  getWalletAggregate as readWallet,
} from "@/api/mocks/packages.mocks";
// Avoid an unused-import warning on `updatePurchase` while keeping it exported
// for future fine-grained mutations from other endpoints (e.g. expirations).
void updatePurchase;
