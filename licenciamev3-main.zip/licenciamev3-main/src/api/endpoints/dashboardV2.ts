import { mockDelay, mockError } from "../client";
import {
  buildDefaultMock,
  buildLowBalanceMock,
  buildNewCompanyMock,
} from "../mocks/dashboardV2.mocks";
import type { DashboardDataV2, DashboardFixture, DashboardPeriod } from "../types.dashboard";

/** Random network delay 400–900ms (heavier than V1 since payload is larger). */
async function dashboardDelay(): Promise<void> {
  const ms = 400 + Math.floor(Math.random() * 500);
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function getDashboardDataV2(
  period: DashboardPeriod = "30d",
  fixture: DashboardFixture = "default",
): Promise<DashboardDataV2> {
  await (fixture === "error" ? mockDelay() : dashboardDelay());

  switch (fixture) {
    case "newCompany":
      return buildNewCompanyMock();
    case "lowBalance":
      return buildLowBalanceMock();
    case "error":
      return mockError("DASHBOARD_LOAD_FAILED", "No pudimos cargar tu dashboard");
    case "default":
    default:
      return buildDefaultMock(period);
  }
}
