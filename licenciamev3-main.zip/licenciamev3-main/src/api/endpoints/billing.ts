/**
 * Billing profile endpoints (F-04 · Block 2).
 *
 * Hand-off backend:
 * - `getBillingProfile` → GET /companies/:id/billing-profile (returns 404 if missing).
 * - `saveBillingProfile` → PUT /companies/:id/billing-profile (upsert).
 * - Backend should validate NIT format server-side and call DIAN webservices
 *   for taxpayer-type verification when integration lands.
 */
import type { BillingProfile } from "@/api/types";
import {
  getBillingProfileMock,
  saveBillingProfileMock,
} from "@/api/mocks/billing.mocks";

function delay(min: number, max: number): Promise<void> {
  return new Promise((r) => setTimeout(r, min + Math.random() * (max - min)));
}

export const billingApi = {
  async getBillingProfile(): Promise<BillingProfile | null> {
    await delay(200, 400);
    return getBillingProfileMock();
  },

  async saveBillingProfile(profile: BillingProfile): Promise<BillingProfile> {
    await delay(300, 600);
    return saveBillingProfileMock(profile);
  },
};
