import type { UserActivity, UserActivityType } from "../types.dashboard";
import { mockDelay } from "../client";
import { buildUserActivityFeedMock } from "../mocks/activity.mocks";

export interface ActivityListParams {
  from?: string;
  to?: string;
  types?: UserActivityType[];
  actors?: string[];
  cursor?: string | null;
  pageSize?: number;
}

export interface ActivityListResponse {
  items: UserActivity[];
  next_cursor: string | null;
}

const ALL = buildUserActivityFeedMock();

/**
 * GET /api/activity?from=&to=&types=&actors=&cursor=
 * Backend filters by origen=user. Mock implements identical filtering shape.
 */
export async function listActivity(params: ActivityListParams): Promise<ActivityListResponse> {
  await mockDelay();

  const { from, to, types, actors, cursor, pageSize = 25 } = params;
  const fromTs = from ? new Date(from).getTime() : -Infinity;
  const toTs = to ? new Date(to).getTime() + 86_399_000 : Infinity;

  const filtered = ALL.filter((item) => {
    const ts = new Date(item.created_at).getTime();
    if (ts < fromTs || ts > toTs) return false;
    if (types && types.length > 0 && !types.includes(item.type)) return false;
    if (actors && actors.length > 0 && !actors.includes(item.actor.user_id)) return false;
    return true;
  });

  const start = cursor ? Number.parseInt(cursor, 10) : 0;
  const end = start + pageSize;
  const slice = filtered.slice(start, end);
  const next_cursor = end < filtered.length ? String(end) : null;

  return { items: slice, next_cursor };
}

/** Distinct actors discovered in the feed — used for the actor filter dropdown. */
export async function listActivityActors(): Promise<{ user_id: string; user_name: string }[]> {
  await mockDelay();
  const seen = new Map<string, string>();
  for (const item of ALL) {
    if (!seen.has(item.actor.user_id)) seen.set(item.actor.user_id, item.actor.user_name);
  }
  return [...seen.entries()].map(([user_id, user_name]) => ({ user_id, user_name }));
}