/**
 * Social accounts endpoints (F-07).
 *
 * Backend hand-off:
 *  - `list()` → `GET /api/social-accounts` returning `SocialAccount[]`.
 *  - `connect(platform)` → `POST /api/social-accounts/oauth/callback`.
 *  - `reconnect(id)` → `POST /api/social-accounts/:id/oauth/refresh`.
 *  - `disconnect(id)` → `DELETE /api/social-accounts/:id`.
 *  - `setPrimary(id)` → `PATCH /api/social-accounts/:id/primary`.
 *
 * Components depend ONLY on this file, never on `mocks/social.mocks.ts`.
 */
import {
  ConnectFlowError,
  type SocialAccount,
  type SocialPlatformF06,
} from "@/api/types";
import {
  DUPLICATE_ACCOUNT_DEMO_ACCOUNT,
  ERROR_DEMO_ACCOUNT,
  PERMISSIONS_REVOKED_DEMO_ACCOUNT,
  SOCIAL_ACCOUNTS_SEED,
  removeMockAccount,
  setPrimaryAccount,
  upsertMockAccount,
} from "@/api/mocks/social.mocks";
import { generateMockConnection } from "@/modules/social/components/ConnectFlow/ConnectFlow.utils";

function delay(min: number, max: number): Promise<void> {
  return new Promise((r) => setTimeout(r, min + Math.random() * (max - min)));
}

export interface ConnectOptions {
  /** Forces a `popup_blocked` rejection (driven by debug panel). */
  simulatePopupBlocked?: boolean;
  /** Forces an `account_taken` rejection (driven by debug panel). */
  simulateAccountTaken?: boolean;
  /** When set, reuses the existing account id (reconnect flow). */
  reuseAccountId?: string;
}

export interface ListOptions {
  includeErrorDemo?: boolean;
  /** Mutates Instagram primary to `token_expired` for demo purposes. */
  forceInstagramExpired?: boolean;
  /** Replaces Facebook primary with a `permissions_revoked` demo entry. */
  simulatePermissionsRevoked?: boolean;
  /** Replaces TikTok primary with a `duplicate_account` demo entry. */
  simulateDuplicateAccount?: boolean;
}

export const socialApi = {
  /**
   * Returns all social accounts for the current user.
   */
  async list(options: ListOptions = {}): Promise<SocialAccount[]> {
    await delay(200, 500);
    let base = SOCIAL_ACCOUNTS_SEED.slice();
    if (options.forceInstagramExpired) {
      base = base.map((a) =>
        a.platform === "instagram" && a.connected && a.isPrimary
          ? { ...a, syncStatus: "token_expired" as const }
          : a,
      );
    }
    if (options.simulatePermissionsRevoked) {
      // Replace Facebook primary with the revoked-permissions demo entry,
      // preserving primary flag and id semantics on the array shape.
      base = base.map((a) =>
        a.platform === "facebook" && a.isPrimary
          ? { ...PERMISSIONS_REVOKED_DEMO_ACCOUNT, isPrimary: true }
          : a,
      );
    }
    if (options.simulateDuplicateAccount) {
      base = base.map((a) =>
        a.platform === "tiktok" && a.isPrimary
          ? { ...DUPLICATE_ACCOUNT_DEMO_ACCOUNT, isPrimary: true }
          : a,
      );
      // TikTok seed starts disconnected — if the swap above did nothing
      // because no primary exists, append the demo entry as primary.
      if (!base.some((a) => a.platform === "tiktok" && a.isPrimary)) {
        base.push({ ...DUPLICATE_ACCOUNT_DEMO_ACCOUNT, isPrimary: true });
      }
    }
    if (options.includeErrorDemo) {
      base.push(ERROR_DEMO_ACCOUNT);
    }
    return base;
  },

  /**
   * Simulates the server-side OAuth callback. Resolves with the new account
   * or rejects with a typed `ConnectFlowError` when the debug panel forces it.
   */
  async connect(
    platform: SocialPlatformF06,
    options: ConnectOptions = {},
  ): Promise<SocialAccount> {
    await delay(150, 350);
    const mock = generateMockConnection(platform);

    if (options.simulatePopupBlocked) {
      throw new ConnectFlowError("popup_blocked");
    }
    if (options.simulateAccountTaken) {
      throw new ConnectFlowError("account_taken", mock.username);
    }

    const existing = options.reuseAccountId
      ? SOCIAL_ACCOUNTS_SEED.find((a) => a.id === options.reuseAccountId)
      : undefined;

    const account: SocialAccount = {
      id: existing?.id ?? `sa_${platform}_${Date.now()}`,
      platform,
      username: existing?.username || mock.username,
      displayName: existing?.displayName || mock.displayName,
      avatarUrl: existing?.avatarUrl ?? null,
      connected: true,
      connectedAt: existing?.connectedAt ?? mock.connectedAt,
      tokenExpiresAt: new Date(Date.now() + 60 * 86_400_000).toISOString(),
      syncStatus: "ok",
      lastSyncAt: mock.connectedAt,
      // First account on this platform is primary by default.
      isPrimary:
        existing?.isPrimary ??
        !SOCIAL_ACCOUNTS_SEED.some((a) => a.platform === platform && a.connected),
    };
    upsertMockAccount(account);
    return account;
  },

  /** Convenience wrapper for the reconnect flow. */
  async reconnect(accountId: string, options: ConnectOptions = {}): Promise<SocialAccount> {
    const existing = SOCIAL_ACCOUNTS_SEED.find((a) => a.id === accountId);
    if (!existing) throw new Error(`Account ${accountId} not found`);
    return socialApi.connect(existing.platform, { ...options, reuseAccountId: accountId });
  },

  async disconnect(accountId: string): Promise<{ id: string }> {
    await delay(150, 300);
    removeMockAccount(accountId);
    return { id: accountId };
  },

  async setPrimary(accountId: string): Promise<{ id: string }> {
    await delay(100, 200);
    const target = SOCIAL_ACCOUNTS_SEED.find((a) => a.id === accountId);
    if (!target) throw new Error(`Account ${accountId} not found`);
    setPrimaryAccount(target.platform, accountId);
    return { id: accountId };
  },
};
