/**
 * Catalog mock endpoints.
 *
 * Same signature as the future HTTP client — when the real backend is wired,
 * only the implementation of these functions changes.
 *
 * Dev error toggles (env vars):
 *   - VITE_MOCK_FORCE_CATALOG_ERROR=true  → search()/getTrackById() throw NETWORK_ERROR
 *   - VITE_MOCK_FORCE_PREVIEW_ERROR=true  → reserved for the audio engine layer
 *   - VITE_MOCK_LATENCY_MULTIPLIER=2      → multiply the simulated delay
 */

import type {
  ApiError,
  CatalogFilters,
  CatalogPageRequest,
  CatalogPageResponse,
  Genre,
  LicensablePlatform,
  Mood,
  ToggleFavoriteRequest,
  ToggleFavoriteResponse,
  Track,
  TrackDetailResponse,
  TrackSummary,
} from "@/api/types";
import {
  MOCK_TRACK_REMOVED_ID,
  getAllMockTracks,
  platformsLicensableFor,
} from "@/api/mocks/tracks.mocks";
import { featureFlags } from "@/config/featureFlags";

// ─── Dev helpers ─────────────────────────────────────────────────────────────

function envFlag(key: string): boolean {
  const v = (import.meta.env as Record<string, unknown>)[key];
  return v === "true" || v === true;
}

function latencyMultiplier(): number {
  const v = (import.meta.env as Record<string, unknown>)["VITE_MOCK_LATENCY_MULTIPLIER"];
  const n = typeof v === "string" ? parseFloat(v) : 1;
  return Number.isFinite(n) && n > 0 ? n : 1;
}

function mockDelay(min: number, max: number): Promise<void> {
  const m = latencyMultiplier();
  const ms = (min + Math.random() * (max - min)) * m;
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function makeError(code: string, message: string): ApiError {
  return { code, message };
}

function toSummary(track: Track): TrackSummary {
  return {
    id: track.id,
    title: track.title,
    artist: track.artist,
    coverUrl: track.coverUrl,
    genre: track.genre,
    moods: track.moods,
    durationSec: track.durationSec,
    previewUrl: track.previewUrl,
    waveformPeaks: track.waveformPeaks,
    popularityScore: track.popularityScore,
    platformsLicensable: platformsLicensableFor(track),
    isFavorite: track.isFavorite,
  };
}

// ─── Filtering / sorting ─────────────────────────────────────────────────────

function applyFilters(tracks: Track[], filters: CatalogFilters): Track[] {
  const search = filters.search.trim().toLowerCase();
  const genres = new Set<Genre>(filters.genres);
  const moods = new Set<Mood>(filters.moods);
  const platforms = new Set<LicensablePlatform>(filters.platforms);

  return tracks.filter((t) => {
    if (search) {
      const haystack = `${t.title} ${t.artist} ${t.genre} ${t.tags.join(" ")}`.toLowerCase();
      if (!haystack.includes(search)) return false;
    }
    if (genres.size > 0 && !genres.has(t.genre)) return false;
    if (moods.size > 0 && !t.moods.some((m) => moods.has(m))) return false;
    if (filters.durationRange) {
      const { minSec, maxSec } = filters.durationRange;
      if (t.durationSec < minSec || t.durationSec > maxSec) return false;
    }
    if (platforms.size > 0) {
      const allowed = new Set(platformsLicensableFor(t));
      let hit = false;
      for (const p of platforms) if (allowed.has(p)) { hit = true; break; }
      if (!hit) return false;
    }
    if (filters.onlyFavorites && !t.isFavorite) return false;
    return true;
  });
}

function applySort(tracks: Track[], sort: CatalogFilters["sort"]): Track[] {
  const copy = tracks.slice();
  switch (sort) {
    case "popularity-desc":
      copy.sort((a, b) => b.popularityScore - a.popularityScore);
      break;
    case "recent-desc":
      copy.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      break;
    case "title-asc":
      copy.sort((a, b) => a.title.localeCompare(b.title, "es"));
      break;
    case "title-desc":
      copy.sort((a, b) => b.title.localeCompare(a.title, "es"));
      break;
    case "duration-asc":
      copy.sort((a, b) => a.durationSec - b.durationSec);
      break;
    case "duration-desc":
      copy.sort((a, b) => b.durationSec - a.durationSec);
      break;
    case "artist-asc":
      copy.sort((a, b) => a.artist.localeCompare(b.artist, "es"));
      break;
  }
  return copy;
}

function buildFacets(filtered: Track[]) {
  const genreCounts = new Map<Genre, number>();
  const moodCounts = new Map<Mood, number>();
  for (const t of filtered) {
    genreCounts.set(t.genre, (genreCounts.get(t.genre) ?? 0) + 1);
    for (const m of t.moods) moodCounts.set(m, (moodCounts.get(m) ?? 0) + 1);
  }
  return {
    availableGenres: Array.from(genreCounts.entries())
      .map(([genre, count]) => ({ genre, count }))
      .sort((a, b) => b.count - a.count),
    availableMoods: Array.from(moodCounts.entries())
      .map(([mood, count]) => ({ mood, count }))
      .sort((a, b) => b.count - a.count),
  };
}

function topGenresGlobally(): Genre[] {
  const all = getAllMockTracks();
  const counts = new Map<Genre, number>();
  for (const t of all) counts.set(t.genre, (counts.get(t.genre) ?? 0) + 1);
  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([g]) => g);
}

// ─── Public API ──────────────────────────────────────────────────────────────

export const catalogApi = {
  async search(request: CatalogPageRequest): Promise<CatalogPageResponse> {
    await mockDelay(300, 700);
    if (envFlag("VITE_MOCK_FORCE_CATALOG_ERROR")) {
      throw makeError("NETWORK_ERROR", "No pudimos cargar el catálogo.");
    }
    const all = getAllMockTracks();
    const filtered = applyFilters(all, request.filters);
    const sorted = applySort(filtered, request.filters.sort);
    const totalTracks = sorted.length;
    const totalPages = Math.max(1, Math.ceil(totalTracks / request.pageSize));
    const page = Math.min(Math.max(1, request.page), totalPages);
    const start = (page - 1) * request.pageSize;
    const slice = sorted.slice(start, start + request.pageSize);
    const facets = buildFacets(filtered);
    const suggestedSearches =
      request.filters.search.trim() && slice.length === 0
        ? topGenresGlobally()
        : null;
    return {
      tracks: slice.map(toSummary),
      page,
      pageSize: request.pageSize,
      totalTracks,
      totalPages,
      appliedFilters: request.filters,
      availableGenres: facets.availableGenres,
      availableMoods: facets.availableMoods,
      suggestedSearches,
    };
  },

  async getTrackById(id: string): Promise<TrackDetailResponse> {
    await mockDelay(200, 500);
    if (envFlag("VITE_MOCK_FORCE_CATALOG_ERROR")) {
      throw makeError("NETWORK_ERROR", "No pudimos cargar el detalle.");
    }
    if (id === MOCK_TRACK_REMOVED_ID) {
      throw makeError("TRACK_REMOVED", "Esta canción ya no está disponible.");
    }
    const all = getAllMockTracks();
    const track = all.find((t) => t.id === id);
    if (!track) throw makeError("TRACK_NOT_FOUND", "Canción no encontrada.");
    let similar: TrackSummary[] | null = null;
    if (featureFlags.FEATURE_SIMILAR_TRACKS) {
      similar = all
        .filter((t) => t.genre === track.genre && t.id !== track.id)
        .sort((a, b) => b.popularityScore - a.popularityScore)
        .slice(0, 6)
        .map(toSummary);
    }
    return { track, similarTracks: similar };
  },

  async toggleFavorite(request: ToggleFavoriteRequest): Promise<ToggleFavoriteResponse> {
    await mockDelay(150, 300);
    if (!featureFlags.FEATURE_FAVORITES) {
      throw makeError("FEATURE_DISABLED", "Favoritos no está disponible.");
    }
    const all = getAllMockTracks();
    const track = all.find((t) => t.id === request.trackId);
    if (!track) throw makeError("TRACK_NOT_FOUND", "Canción no encontrada.");
    track.isFavorite = !track.isFavorite;
    return { trackId: track.id, isFavorite: track.isFavorite };
  },

  async getSimilarTracks(trackId: string, limit: number): Promise<TrackSummary[]> {
    await mockDelay(200, 400);
    const all = getAllMockTracks();
    const track = all.find((t) => t.id === trackId);
    if (!track) throw makeError("TRACK_NOT_FOUND", "Canción no encontrada.");
    return all
      .filter((t) => t.genre === track.genre && t.id !== track.id)
      .sort((a, b) => b.popularityScore - a.popularityScore)
      .slice(0, limit)
      .map(toSummary);
  },
};
