import { mockDelay } from "../client";
import { mockDashboardEmpty } from "../mocks/dashboard.mocks";
import type { DashboardData } from "../types";

/**
 * Returns the aggregated dashboard payload for the current user.
 * Mock always returns an empty dataset so widgets render their empty states.
 */
export async function getDashboardData(): Promise<DashboardData> {
  await mockDelay();
  return mockDashboardEmpty;
}
