/**
 * Tracking endpoints (F-06).
 *
 * Mock wrappers over `trackingSimulator`. Same shape backend will implement.
 * Components only depend on this file; they never import the simulator.
 */
import type {
  DetectedPost,
  LicenseAssociatedContent,
  ListDetectedPostsRequest,
  ListDetectedPostsResponse,
  ManualLinkRequest,
  ManualLinkResponse,
  SocialPlatformF06,
  TrackingSyncStatus,
  UnlinkPostRequest,
  UnlinkPostResponse,
} from "@/api/types";
import { mockError } from "@/api/client";
import { licensingApi } from "./licensing";
import { trackingSimulator } from "@/shared/tracking-simulator";
import type { ForceDetectionOptions } from "@/shared/tracking-simulator";

function delay(min: number, max: number): Promise<void> {
  return new Promise((resolve) => {
    const ms = min + Math.random() * (max - min);
    setTimeout(resolve, ms);
  });
}

export const trackingApi = {
  async listDetectedPosts(req: ListDetectedPostsRequest): Promise<ListDetectedPostsResponse> {
    await delay(200, 500);
    const all = trackingSimulator.getAllPosts();
    const fromMs = req.dateRange.from ? new Date(req.dateRange.from).getTime() : null;
    const toMs = req.dateRange.to ? new Date(req.dateRange.to).getTime() : null;

    const filtered = all.filter((post) => {
      if (req.platforms.length && !req.platforms.includes(post.platform)) return false;
      if (req.filter !== "all" && post.matchStatus !== req.filter) return false;
      const ts = new Date(post.detectedAt).getTime();
      if (fromMs != null && ts < fromMs) return false;
      if (toMs != null && ts > toMs) return false;
      return true;
    });

    const totalPosts = filtered.length;
    const totalPages = Math.max(1, Math.ceil(totalPosts / req.pageSize));
    const safePage = Math.min(Math.max(1, req.page), totalPages);
    const start = (safePage - 1) * req.pageSize;
    const posts = filtered.slice(start, start + req.pageSize);

    const aggregates = {
      pendingMatch: all.filter((p) => p.matchStatus === "pending-match").length,
      matchedAuto: all.filter((p) => p.matchStatus === "matched-auto").length,
      matchedManual: all.filter((p) => p.matchStatus === "matched-manual").length,
      noMatchFound: all.filter((p) => p.matchStatus === "no-match-found").length,
      unlinked: all.filter((p) => p.matchStatus === "unlinked").length,
    };

    return {
      posts,
      page: safePage,
      pageSize: req.pageSize,
      totalPosts,
      totalPages,
      aggregates,
      syncStatus: trackingSimulator.getSyncStatus(),
    };
  },

  async getPostById(postId: string): Promise<DetectedPost> {
    await delay(200, 500);
    const post = trackingSimulator.getPostById(postId);
    if (!post) mockError("POST_NOT_FOUND", "Publicación no encontrada.");
    return post!;
  },

  async getLicenseAssociatedContent(licenseId: string): Promise<LicenseAssociatedContent> {
    await delay(200, 500);
    const posts = trackingSimulator.getPostsByLicense(licenseId);
    let canLinkManually = false;
    try {
      const license = await licensingApi.getLicenseById(licenseId);
      canLinkManually = license.status === "active";
    } catch {
      canLinkManually = false;
    }
    return { licenseId, posts, canLinkManually };
  },

  async linkPostManually(req: ManualLinkRequest): Promise<ManualLinkResponse> {
    await delay(500, 1000);
    if (!isValidUrl(req.externalUrl)) {
      mockError("URL_INVALID", "La URL no es válida.");
    }
    return trackingSimulator.manuallyLinkPost(req);
  },

  async unlinkPost(req: UnlinkPostRequest): Promise<UnlinkPostResponse> {
    await delay(300, 600);
    return trackingSimulator.unlinkPost(req);
  },

  async getSyncStatus(): Promise<TrackingSyncStatus> {
    await delay(150, 300);
    return trackingSimulator.getSyncStatus();
  },

  async triggerManualSync(): Promise<{ triggered: boolean; expectedDurationMs: number }> {
    await delay(800, 1500);
    return { triggered: true, expectedDurationMs: 5_000 };
  },

  // ─── Dev-only ──────────────────────────────────────────────────────────────

  async dev_triggerDetection(options: ForceDetectionOptions = {}): Promise<DetectedPost> {
    if (!import.meta.env.DEV) {
      mockError("PLATFORM_SYNC_UNAVAILABLE", "Solo disponible en desarrollo.");
    }
    return trackingSimulator.triggerDetection(options);
  },

  async dev_triggerError(
    platform: SocialPlatformF06,
    errorType: string,
  ): Promise<{ triggered: boolean }> {
    if (!import.meta.env.DEV) {
      mockError("PLATFORM_SYNC_UNAVAILABLE", "Solo disponible en desarrollo.");
    }
    trackingSimulator.triggerError(platform, errorType);
    return { triggered: true };
  },
};

function isValidUrl(url: string): boolean {
  try {
    const u = new URL(url);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}
