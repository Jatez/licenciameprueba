import type { ApiError, AuthErrorCode } from "./types";

/**
 * Mock client. Same shape as the future axios wrapper so endpoints
 * never need to change when backend connects.
 *
 * When the real backend lands:
 *   - Replace this file with an axios instance.
 *   - Delete src/api/mocks/.
 *   - Endpoints in src/api/endpoints/ stay identical.
 */

/** Random network delay 200–800ms. */
export function mockDelay(): Promise<void> {
  const ms = 200 + Math.floor(Math.random() * 600);
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Build and throw an ApiError matching what backend will return. */
export function mockError(code: AuthErrorCode | string, message: string, field?: string): never {
  const error: ApiError = field ? { code, message, field } : { code, message };
  throw error;
}

/** Type guard so React Query error handlers can narrow safely. */
export function isApiError(value: unknown): value is ApiError {
  return (
    typeof value === "object" &&
    value !== null &&
    "code" in value &&
    "message" in value &&
    typeof (value as { code: unknown }).code === "string" &&
    typeof (value as { message: unknown }).message === "string"
  );
}
