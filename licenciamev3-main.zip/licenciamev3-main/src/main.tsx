import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./i18n";
import "./index.css";
import { trackingSimulator } from "@/shared/tracking-simulator";

// Tracking simulator runs in all environments (UI-only demo project).
void trackingSimulator.start();

createRoot(document.getElementById("root")!).render(<App />);
