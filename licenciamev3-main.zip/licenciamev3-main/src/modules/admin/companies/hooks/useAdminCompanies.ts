import { useCallback, useMemo, useState } from "react";
import { adminCompaniesMocks } from "../mocks";
import {
  COMPANIES_DEFAULT_FILTERS,
  type AdminCompany,
  type CompaniesFiltersState,
} from "../types";

export function useAdminCompanies() {
  const [companies, setCompanies] = useState<AdminCompany[]>(adminCompaniesMocks);
  const [filters, setFilters] = useState<CompaniesFiltersState>(COMPANIES_DEFAULT_FILTERS);

  const resetFilters = useCallback(() => setFilters(COMPANIES_DEFAULT_FILTERS), []);

  const setStatus = useCallback((id: string, status: AdminCompany["status"]) => {
    setCompanies((prev) => prev.map((c) => (c.id === id ? { ...c, status } : c)));
  }, []);

  const assignCustomPlan = useCallback(
    (id: string, credits: number, label: string) => {
      setCompanies((prev) =>
        prev.map((c) =>
          c.id === id
            ? {
                ...c,
                plan: "custom",
                planLabel: label,
                wallet: {
                  ...c.wallet,
                  creditsAvailable: c.wallet.creditsAvailable + credits,
                  creditsTotal: c.wallet.creditsTotal + credits,
                  lastTopUpAt: new Date().toISOString(),
                },
              }
            : c,
        ),
      );
    },
    [],
  );

  const filtered = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    return companies.filter((c) => {
      if (filters.status !== "all" && c.status !== filters.status) return false;
      if (filters.plan !== "all" && c.plan !== filters.plan) return false;
      if (q) {
        const blob =
          `${c.name} ${c.legalName} ${c.taxId} ${c.primaryContactName} ${c.primaryContactEmail}`.toLowerCase();
        if (!blob.includes(q)) return false;
      }
      return true;
    });
  }, [companies, filters]);

  const stats = useMemo(
    () => ({
      total: companies.length,
      active: companies.filter((c) => c.status === "active").length,
      suspended: companies.filter((c) => c.status === "suspended").length,
      creditsCirculating: companies.reduce((acc, c) => acc + c.wallet.creditsAvailable, 0),
    }),
    [companies],
  );

  return {
    companies,
    filtered,
    filters,
    setFilters,
    resetFilters,
    setStatus,
    assignCustomPlan,
    stats,
  };
}
