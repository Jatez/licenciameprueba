import { useCallback, useState } from "react";
import {
  adminCompanyUsersMocks,
  adminSuperAdminsMocks,
  adminInvitationsMocks,
} from "../mocks";
import type { AccessUser, InviteRole, PendingInvitation } from "../types";

export function useAdminAccess() {
  const [companyUsers, setCompanyUsers] = useState<AccessUser[]>(adminCompanyUsersMocks);
  const [superAdmins, setSuperAdmins] = useState<AccessUser[]>(adminSuperAdminsMocks);
  const [invitations, setInvitations] = useState<PendingInvitation[]>(adminInvitationsMocks);

  const updateUser = useCallback((id: string, patch: Partial<AccessUser>) => {
    const apply = (prev: AccessUser[]) => prev.map((u) => (u.id === id ? { ...u, ...patch } : u));
    setCompanyUsers(apply);
    setSuperAdmins(apply);
  }, []);

  const setStatus = useCallback(
    (id: string, status: AccessUser["status"]) => updateUser(id, { status }),
    [updateUser],
  );
  const setRole = useCallback(
    (id: string, role: InviteRole) => updateUser(id, { role }),
    [updateUser],
  );
  const resetMfa = useCallback(
    (id: string) => updateUser(id, { mfaEnabled: false, status: "pending_mfa" }),
    [updateUser],
  );

  const resendInvitation = useCallback((id: string) => {
    setInvitations((prev) =>
      prev.map((i) =>
        i.id === id
          ? {
              ...i,
              invitedAt: new Date().toISOString(),
              expiresAt: new Date(Date.now() + 3 * 86_400_000).toISOString(),
              status: "pending",
            }
          : i,
      ),
    );
  }, []);

  const revokeInvitation = useCallback((id: string) => {
    setInvitations((prev) => prev.filter((i) => i.id !== id));
  }, []);

  const stats = {
    total: companyUsers.length + superAdmins.length,
    active:
      companyUsers.filter((u) => u.status === "active").length +
      superAdmins.filter((u) => u.status === "active").length,
    pending: invitations.filter((i) => i.status === "pending").length,
    superAdmins: superAdmins.length,
  };

  return {
    companyUsers,
    superAdmins,
    invitations,
    setStatus,
    setRole,
    resetMfa,
    resendInvitation,
    revokeInvitation,
    stats,
  };
}
