import {
  AdminPageTitle,
  AdminSectionTitle,
  AdminMetricCard,
  AdminAlertCard,
  AdminQuickActionCard,
  adminMetricsMock,
  adminAlertsMock,
  adminQuickActionsMock,
  adminStrings,
} from "@/modules/admin";

/**
 * F-09 Overview — global Super Admin dashboard.
 * 100% mock data. Replace adminMetricsMock/etc. with API calls when backend lands.
 */
export default function AdminDashboard() {
  const t = adminStrings.overview;

  return (
    <>
      <AdminPageTitle title={t.pageTitle} subtitle={t.pageSubtitle} />

      <section aria-labelledby="admin-metrics-heading" className="pb-10">
        <AdminSectionTitle title={t.metricsHeading} hint={t.metricsHint} />
        <div
          id="admin-metrics-heading"
          className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4"
        >
          {adminMetricsMock.map((metric) => (
            <AdminMetricCard key={metric.key} metric={metric} />
          ))}
        </div>
      </section>

      <section aria-labelledby="admin-alerts-heading" className="pb-10">
        <AdminSectionTitle title={t.alertsHeading} hint={t.alertsHint} />
        <div
          id="admin-alerts-heading"
          className="grid grid-cols-1 gap-4 md:grid-cols-2"
        >
          {adminAlertsMock.map((alert) => (
            <AdminAlertCard key={alert.id} alert={alert} />
          ))}
        </div>
      </section>

      <section aria-labelledby="admin-quick-actions-heading" className="pb-4">
        <AdminSectionTitle title={t.quickActionsHeading} hint={t.quickActionsHint} />
        <div
          id="admin-quick-actions-heading"
          className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3"
        >
          {adminQuickActionsMock.map((action) => (
            <AdminQuickActionCard key={action.key} action={action} />
          ))}
        </div>
      </section>
    </>
  );
}
