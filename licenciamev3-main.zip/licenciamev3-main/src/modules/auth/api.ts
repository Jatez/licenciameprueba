/**
 * Auth API contract (mocked).
 *
 * Functions match what backend will expose. Today they resolve mocks with
 * realistic delay + TODO(backend) markers describing the real endpoint.
 * The day backend lands, swap the bodies for `http.<verb>(...)` calls —
 * signatures, payloads and return shapes do not change.
 */
import { mockDelay } from "@/api/client";
import type {
  AuthTokens,
  Company,
  RegisterRequest,
  RegisterResponse,
  User,
  UserRole,
} from "@/api/types";
import {
  mockCompanyDualtee,
  mockTokensPair,
  mockUserVerified,
} from "@/api/mocks/auth.mocks";

export interface LoginRequest {
  email: string;
  password: string;
  remember?: boolean;
}

export interface LoginResponse {
  user: User;
  company: Company;
  tokens: AuthTokens;
}

export interface RefreshRequest {
  refreshToken: string;
}

/** Inferred role from email for mock convenience. */
function inferRoleFromEmail(email: string): UserRole {
  const e = email.toLowerCase();
  if (e.includes("admin")) return "super_admin";
  if (e.includes("manager")) return "manager";
  return "company_admin";
}

/**
 * TODO(backend): POST /auth/login
 * Request: { email, password, remember? }
 * Response: { user, company, tokens }
 * Errors: INVALID_CREDENTIALS (401), ACCOUNT_LOCKED (423), ACCOUNT_DISABLED (403).
 */
export async function login(payload: LoginRequest): Promise<LoginResponse> {
  await mockDelay();
  const role = inferRoleFromEmail(payload.email);
  const user: User = { ...mockUserVerified, email: payload.email, role };
  return { user, company: mockCompanyDualtee, tokens: mockTokensPair };
}

/**
 * TODO(backend): POST /auth/register
 * Request: RegisterRequest. Response: RegisterResponse.
 */
export async function register(payload: RegisterRequest): Promise<RegisterResponse> {
  // Delegates to the existing mock endpoint to keep a single source of truth.
  const { register: registerEndpoint } = await import("@/api/endpoints/auth");
  return registerEndpoint(payload);
}

/**
 * TODO(backend): POST /auth/refresh
 * Request: { refreshToken }. Response: { accessToken, refreshToken }.
 * Used by the http interceptor on 401 to attempt one silent retry.
 */
export async function refresh(_payload: RefreshRequest): Promise<AuthTokens> {
  await mockDelay();
  return mockTokensPair;
}

/**
 * TODO(backend): POST /auth/logout
 * Invalidates the refresh token server-side. No body, 204 expected.
 */
export async function logout(): Promise<void> {
  await mockDelay();
}

/**
 * TODO(backend): GET /auth/me
 * Returns the current user from the bearer token.
 */
export async function getCurrentUser(): Promise<User> {
  const { getCurrentUser: get } = await import("@/api/endpoints/auth");
  return get();
}

/**
 * TODO(backend): GET /companies/me
 * Returns the company tied to the current user.
 */
export async function getCompany(): Promise<Company> {
  await mockDelay();
  return mockCompanyDualtee;
}

/**
 * TODO(backend): OAuth — Meta (Facebook/Instagram) login.
 * Real flow: redirect to /auth/oauth/meta, backend handles callback,
 * returns to /auth-success with a one-time code; frontend exchanges code for tokens.
 */
export async function loginWithMeta(): Promise<void> {
  await mockDelay();
  // No-op stub. Real impl: window.location.href = `${API_BASE}/auth/oauth/meta`;
}

/**
 * TODO(backend): OAuth — TikTok login.
 * Same flow as Meta but with the TikTok provider.
 */
export async function loginWithTikTok(): Promise<void> {
  await mockDelay();
  // No-op stub. Real impl: window.location.href = `${API_BASE}/auth/oauth/tiktok`;
}